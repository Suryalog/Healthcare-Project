package com.project.Healthcare;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HealthcareApplicationTests {

	@Test
	void contextLoads() {
	}

}
