package com.project.Healthcare.Exception;

public class InvalidEmailidException extends RuntimeException{
	public InvalidEmailidException(String message) {
		super(message);
	}

}
