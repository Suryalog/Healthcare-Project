package com.project.Healthcare.security;

public class UserInfoUserDetails {

}
