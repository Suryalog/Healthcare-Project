//package com.project.Healthcare.Exception;
//
//public class SQLIntegrityConstraintViolationException extends Exception{
//	public SQLIntegrityConstraintViolationException(String message) {
//		super(message);
//		
//	}
//
//}
