package com.project.Healthcare.Model;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Sugartest {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long testid;
    private long userid;
    private int age;
    private String gender;
    private LocalDate date;
	@Column(name="fasting sugartest(mmol/L")
	private double Fastingtest;
	@Column(name="Gulcosetest(mmol/L")
	private double Gulcosetest;
	private double AICtest;
	
	public long getTestid() {
		return testid;
	}
	public void setTestid(long testid) {
		this.testid = testid;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	public long getUserid() {
		return userid;
	}
	public void setUserid(long userid) {
		this.userid = userid;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public double getFastingtest() {
		return Fastingtest;
	}
	public void setFastingtest(double fastingtest) {
		Fastingtest = fastingtest;
	}
	public double getGulcosetest() {
		return Gulcosetest;
	}
	public void setGulcosetest(double gulcosetest) {
		Gulcosetest = gulcosetest;
	}
	public double getAICtest() {
		return AICtest;
	}
	public void setAICtest(double aICtest) {
		AICtest = aICtest;
	}
	
	
}
