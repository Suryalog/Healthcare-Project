import React from "react";
import Form from 'react-bootstrap/Form';
import { Col,Row } from "react-bootstrap";
import axios from "axios";
import './Bptest.css';
import { useState } from "react";
import { useNavigate } from "react-router-dom";

const  Bptest=()=>{
    const nav=useNavigate();
   
 const[bp,setBp]=useState([{userid:"",age:"",gender:"",date:"",systolicBP:"",s_range:"",diastolicBP:"",d_range:""}]);
const handleBp= (e) => {
    const { name, value } = e.target;
    setBp(prevState => ({
      ...prevState,
      [name]: value
    }));
  };

  const handlebpbutton = (e) => {
    e.preventDefault();
    console.log(bp);
    if(bp.userid != null && bp.age != null && bp.gender != null && bp.date != null && bp.systolicBP != null && bp.s_range != null
        && bp.diastolicBP != null && bp.d_range != null){
    axios.post("http://localhost:8080/pressure",bp).then(res=> alert("BP report updated"), nav("/testl"));
    console.log(bp);
    }
    else{
        alert("Enter all the Required fields");
    }
  };

    return(
      <div>
        <h3 className="bpheading">BloodPressure test</h3>
        <Form className="bpfor" onSubmit={handlebpbutton}>
            <div className="bpdiv">
                  <Form.Group as={Row} className="mb-3" controlId="formHorizontalEmail">
                    <Form.Label column sm={4}>
                      userId
                    </Form.Label>
                    <Col sm={7}>
                      <Form.Control type="number" placeholder="Enter the Userid" name="userid" onChange={handleBp}/>
                    </Col>
                  </Form.Group>

                  <Form.Group as={Row} className="mb-3" controlId="formHorizontalPassword" >
                    <Form.Label column sm={4}>
                      Age
                    </Form.Label>
                    <Col sm={7}>
                      <Form.Control type="number" placeholder="Enter the Age" name="age" onChange={handleBp}/>
                    </Col>
                  </Form.Group>

                  <Form.Group as={Row} className="mb-3" controlId="formHorizontalPassword">
                    <Form.Label column sm={4}>
                      Gender
                    </Form.Label>
                    <Col sm={7}>
                      <Form.Control type="text" placeholder="Gender" name="gender" onChange={handleBp}/>
                    </Col>
                  </Form.Group>

                  <Form.Group as={Row} className="mb-3" controlId="formHorizontalPassword">
                    <Form.Label column sm={4}>
                      Date
                    </Form.Label>
                    <Col sm={7}>
                      <Form.Control type="date" placeholder="Date" name="date"  onChange={handleBp}/>
                    </Col>
                  </Form.Group>

                  <Form.Group as={Row} className="mb-3" controlId="formHorizontalPassword">
                    
                      <Form.Label column sm={4}>
                      SystolicBP
                        </Form.Label>
                      <Col sm={7}>
                     <Form.Control type="number" step="0.01" placeholder="SystolicBP" name="systolicBP" onChange={handleBp}/>
                     </Col>
                </Form.Group>

                
              <Form.Group as={Row} className="mb-3" controlId="formHorizontalPassword">
                    
                    <Form.Label column sm={4}>
                    Systolic_range:
                      </Form.Label>
                    <Col sm={7}>
                   <Form.Control type="text"  placeholder="Enter the range" name="s_range" onChange={handleBp}/>
                   </Col>
              </Form.Group>

                    <Form.Group as={Row} className="mb-3" controlId="formHorizontalPassword">
                    
                      <Form.Label column sm={4}>
                      DiastolicBp
                        </Form.Label>
                      <Col sm={7}>
                     <Form.Control type="number" step="0.01" placeholder="Enter value DiastolicBP" name="diastolicBP" onChange={handleBp}/>
                     </Col>
                     </Form.Group>


                     <Form.Group as={Row} className="mb-3" controlId="formHorizontalPassword">
                    
                    <Form.Label column sm={4}>
                    Diastolic_range:
                      </Form.Label>
                    <Col sm={7}>
                   <Form.Control type="text"  placeholder="Enter the range" name="d_range" onChange={handleBp}/>
                   </Col>
                 </Form.Group>


                     <Col sm={{ span: 10, offset: 2 }}>
                         <button type="submit" className="Bpbutton">Submit</button>
                    </Col>
                
                </div>
               
              </Form>    

    </div>
    )
}
export default Bptest;