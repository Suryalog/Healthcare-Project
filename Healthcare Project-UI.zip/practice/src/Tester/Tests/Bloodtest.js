import React from 'react'
import Form from 'react-bootstrap/Form';
import { Col,Row } from "react-bootstrap";
import { useState } from "react";
import './Bloodtest.css';
import axios from "axios";
import { useNavigate } from "react-router-dom";

const Bloodtest = () => {
    const nav=useNavigate();
    const[blood,setBlood]=useState([{userid:"",age:"",gender:"",date:"",hemoglobin:"",rbc:"",wbc:"",platelet:"",calcium:""}]);
    const handleBlood = (e) => {
        const { name, value } = e.target;
        setBlood(prevState => ({
          ...prevState,
          [name]: value
        }));
      };
    
      const handlebloodbutton = (e) => {
        e.preventDefault();
        if(blood.userid != null && blood.age != null && blood.gender != null && blood.date != null && blood.hemoglobin != null && blood.rbc != null && blood.wbc != null &&
        blood.platelet != null && blood.calcium != null){
        axios.post("http://localhost:8080/blood",blood).then(res=> alert("Blood report updated"), nav("/testl"));
        console.log(blood);
        }
        else{
            alert("Enter the all required field");
        }
      };
    
        return(
        <div>
            <h3 className="bloodheading">Blood test</h3>
               <Form className="bloodfor" onSubmit={handlebloodbutton}>
                <div className="blooddiv">
                      <Form.Group as={Row} className="mb-3" controlId="formHorizontalEmail">
                        <Form.Label column sm={4}>
                          userId
                        </Form.Label>
                        <Col sm={7}>
                          <Form.Control type="number" placeholder="Enter the Userid" name="userid" onChange={handleBlood}/>
                        </Col>
                      </Form.Group>
    
                      <Form.Group as={Row} className="mb-3" controlId="formHorizontalPassword" >
                        <Form.Label column sm={4}>
                          Age
                        </Form.Label>
                        <Col sm={7}>
                          <Form.Control type="number" placeholder="Enter the Age" name="age" onChange={handleBlood}/>
                        </Col>
                      </Form.Group>
    
                      <Form.Group as={Row} className="mb-3" controlId="formHorizontalPassword">
                        <Form.Label column sm={4}>
                          Gender
                        </Form.Label>
                        <Col sm={7}>
                          <Form.Control type="text" placeholder="Gender" name="gender" onChange={handleBlood}/>
                        </Col>
                      </Form.Group>
    
                      <Form.Group as={Row} className="mb-3" controlId="formHorizontalPassword">
                        <Form.Label column sm={4}>
                          Date
                        </Form.Label>
                        <Col sm={7}>
                          <Form.Control type="date" placeholder="Date" name="date"  onChange={handleBlood}/>
                        </Col>
                      </Form.Group>
    
                      <Form.Group as={Row} className="mb-3" controlId="formHorizontalPassword">
                        
                          <Form.Label column sm={4}>
                          Hemoglobin(g/dl)
                            </Form.Label>
                          <Col sm={7}>
                         <Form.Control type="number" step="0.01" placeholder="Enter the Hemoglobin value" name="hemoglobin" onChange={handleBlood}/>
                         </Col>
                    </Form.Group>
    
                    
                  <Form.Group as={Row} className="mb-3" controlId="formHorizontalPassword">
                        
                        <Form.Label column sm={4}>
                        RBC(10^6/ul)
                          </Form.Label>
                        <Col sm={7}>
                       <Form.Control type="number" step="0.01" placeholder="Enter the RBC value" name="rbc" onChange={handleBlood}/>
                       </Col>
                  </Form.Group>
    
                  <Form.Group as={Row} className="mb-3" controlId="formHorizontalPassword">
                        
                          <Form.Label column sm={4}>
                          WBC(n/mm2)
                            </Form.Label>
                          <Col sm={7}>
                         <Form.Control type="number" step="0.01" placeholder="Enter WBC values" name="wbc" onChange={handleBlood}/>
                         </Col>
                    </Form.Group>

                    <Form.Group as={Row} className="mb-3" controlId="formHorizontalPassword">
                        
                          <Form.Label column sm={4}>
                          platelet(n/mm3)
                            </Form.Label>
                          <Col sm={7}>
                         <Form.Control type="number" step="0.01" placeholder="Enter Platelets values" name="platelet" onChange={handleBlood}/>
                         </Col>
                    </Form.Group>

                    <Form.Group as={Row} className="mb-3" controlId="formHorizontalPassword">
                        
                        <Form.Label column sm={4}>
                         Calcium(d/gl)
                          </Form.Label>
                        <Col sm={7}>
                       <Form.Control type="number" step="0.01" placeholder="Enter Calcium values" name="calcium" onChange={handleBlood}/>
                       </Col>
                  </Form.Group>

                         <Col sm={{ span: 10, offset: 2 }}>
                             <button type="submit" className="bloodbutton">Submit</button>
                        </Col>
                   

                    </div>
                   
                  </Form>    
    
        </div>
        )
    }

export default Bloodtest
