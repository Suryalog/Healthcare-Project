import React from "react";
import Form from 'react-bootstrap/Form';
import { Col,Row } from "react-bootstrap";
import { useState } from "react";
import './Sugartest.css';
import axios from "axios";
import { useNavigate } from "react-router-dom";

const Sugartest=()=>{
 const nav=useNavigate();
const[sugar,setSugar]=useState([{userid:"",age:"",gender:"",date:"",fastingtest:"",gulcosetest:"",aictest:""}]);
const handleSugar = (e) => {
    const { name, value } = e.target;
    setSugar(prevState => ({
      ...prevState,
      [name]: value
    }));
  };

  const handlesugarbutton = (e) => {
    e.preventDefault();
    if(sugar.userid != null && sugar.age != null && sugar.gender != null && sugar.date != null && sugar.fastingtest != null
        && sugar.gulcosetest != null && sugar.aictest != null){
    axios.post("http://localhost:8080/sugar",sugar).then(res=> alert("Sugar report updated"), nav("/testl"));
    console.log(sugar);
   }
   else{
    alert("Enter all Required fields");
   }

  };

    return(
    <div>
        <h3 className="tsugar">Sugar test</h3>
           <Form className="tfor" onSubmit={handlesugarbutton}>
            <div className="tdiv">
                  <Form.Group as={Row} className="mb-3" controlId="formHorizontalEmail">
                    <Form.Label column sm={4}>
                      userId
                    </Form.Label>
                    <Col sm={7}>
                      <Form.Control type="number" placeholder="Enter the Userid" name="userid" onChange={handleSugar}/>
                    </Col>
                  </Form.Group>

                  <Form.Group as={Row} className="mb-3" controlId="formHorizontalPassword" >
                    <Form.Label column sm={4}>
                      Age
                    </Form.Label>
                    <Col sm={7}>
                      <Form.Control type="number" placeholder="Enter the Age" name="age" onChange={handleSugar}/>
                    </Col>
                  </Form.Group>

                  <Form.Group as={Row} className="mb-3" controlId="formHorizontalPassword">
                    <Form.Label column sm={4}>
                      Gender
                    </Form.Label>
                    <Col sm={7}>
                      <Form.Control type="text" placeholder="Gender" name="gender" onChange={handleSugar}/>
                    </Col>
                  </Form.Group>

                  <Form.Group as={Row} className="mb-3" controlId="formHorizontalPassword">
                    <Form.Label column sm={4}>
                      Date
                    </Form.Label>
                    <Col sm={7}>
                      <Form.Control type="date" placeholder="Date" name="date"  onChange={handleSugar}/>
                    </Col>
                  </Form.Group>

                  <Form.Group as={Row} className="mb-3" controlId="formHorizontalPassword">
                    
                      <Form.Label column sm={4}>
                        Fasting Sugar Test (mmol/L)
                        </Form.Label>
                      <Col sm={7}>
                     <Form.Control type="number" step="0.01" placeholder="Fasting Sugar Test" name="fastingtest" onChange={handleSugar}/>
                     </Col>
                </Form.Group>

                
              <Form.Group as={Row} className="mb-3" controlId="formHorizontalPassword">
                    
                    <Form.Label column sm={4}>
                      Gulcosetest Test (mmol/L)
                      </Form.Label>
                    <Col sm={7}>
                   <Form.Control type="number" step="0.01" placeholder="Enter the Gulcosetest value" name="gulcosetest" onChange={handleSugar}/>
                   </Col>
              </Form.Group>

              <Form.Group as={Row} className="mb-3" controlId="formHorizontalPassword">
                    
                      <Form.Label column sm={4}>
                        AIC test
                        </Form.Label>
                      <Col sm={7}>
                     <Form.Control type="number" step="0.01" placeholder="Enter value AIC" name="aictest" onChange={handleSugar}/>
                     </Col>

                     <Col sm={{ span: 10, offset: 2 }}>
                         <button type="submit" className="tbutton">Submit</button>
                    </Col>
                </Form.Group>
                </div>
               
              </Form>    

    </div>
    )
}
export default Sugartest;