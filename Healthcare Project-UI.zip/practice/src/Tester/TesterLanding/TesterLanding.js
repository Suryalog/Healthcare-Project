import React from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faDiagnoses, faSquarePollVertical,  faTableCells} from '@fortawesome/free-solid-svg-icons';
import './TesterLanding.css';
import { useNavigate } from "react-router-dom";
const TesterLanding=()=>{
    const nav=useNavigate();
    return(
        <div>
            <h1 className="thead">Test Details</h1>
        <div className="tland">
       <div className="tapt"><FontAwesomeIcon style={{ fontSize: '9em'}} icon={faSquarePollVertical}  className="ticon" onClick={()=>nav("/sugartest")} />
       <div className="tdi">Sugar Test</div>
       </div>
       <div className="tapt"><FontAwesomeIcon style={{ fontSize: '9em'}} icon={faDiagnoses}  className="ticon" onClick={()=>nav("/bptest")} />
       <div className="tdi">Blood Pressure Test</div>
       </div>
       <div className="tapt"><FontAwesomeIcon style={{ fontSize: '9em'}} icon={faTableCells}  className="ticon" onClick={()=>nav("/bloodtest")}/>
       <div className="tdi">Blood Test</div>
       </div>
       </div>
     
    </div>
    );

}
export default TesterLanding;
