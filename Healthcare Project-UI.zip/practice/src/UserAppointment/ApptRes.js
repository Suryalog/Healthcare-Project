import React, { useEffect } from 'react'
import { useState } from 'react';
import axios from 'axios';
import { Stack } from 'react-bootstrap';
import './AppRes.css';

const ApptRes = () => {
  var [result,setResult]=useState([]);

  useEffect(()=>{
    const user=JSON.parse(sessionStorage.getItem('currentUser'));
    var usid=user.user_id;
    console.log(usid);
    axios.get(`http://localhost:8080/showappointment/${usid}`).then(res=>setResult(res.data))
    .catch(e=>alert(e.data));
  },[])
  return (
    <div className="result">
      <h1 className="header">Appointments Results</h1>
       <Stack gap={3}>
        {result.map((ele,index)=>(
 <div key={index} className="p-2" style={{
  backgroundColor: ele.includes("approved") ? "#90D26D" :
                   ele.includes("declined") ? "#D22D4C" :
                   ele.includes("pending") ? "#F3CA52" : "none"
}} >{ele}</div>
        ))}
    </Stack>

    </div>
  )
}

export default ApptRes
