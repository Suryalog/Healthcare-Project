import React, { useEffect, useState } from 'react'
import Form from 'react-bootstrap/Form';
import './Appointment.css';
import axios from 'axios';
import Dropdown from 'react-bootstrap/Dropdown';
import { Button } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';




export default function SelectBasicExample() {
  const nav=useNavigate();
const [name,setName]=useState('Select for Specialization');
const [spec,setSpec]=useState([]);
const[doc,setDoc]=useState([]);
const[apt,setApt]=useState({userid:"",doctorid:"",date:"",time:""});
const[docholder,setDoctorholder]=useState('Doctors available')
const [date, setDate] = useState('');
  const [time12hr, setTime12hr] = useState('');
  const [time24hr, setTime24hr] = useState('');


  function handleDateChange(e){ 
    setDate(e.target.value);
  }
  

const handleTimeChange = (e) => {
  const timeValue = e.target.value;
  convertTo24HrFormat(timeValue); // Convert to 24-hour format first
  setTime12hr(timeValue); // Update the 12-hour time state
};

const convertTo24HrFormat = (time12h) => {
  const [time, modifier] = time12h.split(' ');
  let [hours, minutes] = time.split(':');
  if (hours === '12') {
    hours = '00';
  }
  if (modifier === 'PM' && hours !== '12') {
    hours = parseInt(hours, 10) + 12;
  }
  const time24hr = `${hours}:${minutes}`;
  setTime24hr(time24hr); // Update the 24-hour time state
  setApt(prev => ({...prev, time: time24hr})); // Update the apt state with the 24-hour time
};


  const handleSubmit = (e) => {
    e.preventDefault();
    const updatedApt = {...apt, date: date, time: time24hr}; // Create a new object with the latest state
    console.log(updatedApt); // Log the updated appointment details
    axios.post("http://localhost:8080/appointmentbook", updatedApt)
      .then(res => {
        alert("Your Appointment was successfully booked");
        nav("/book");
      })
      .catch(e => {
        alert(e.response?.data || e.message); // Access the correct error message property
      });
  };








useEffect(()=>{
 axios.get("http://localhost:8080/spectype").then(res=> setSpec(res.data))
},[]);

function handledoctor(e){
  const value=e.target.value;
  console.log(value);
    axios.get(`http://localhost:8080/docname/${value}`).then(res=>setDoc(res.data))
    .catch(e=>console.log(e));
  };
  
function docGetter(ele)
{
setDoctorholder(ele.name);
console.log(ele.doctor_id)
setApt( (prev) => ({...prev,doctorid:ele.doctor_id,userid:JSON.parse( sessionStorage.getItem('currentUser')).user_id}))
}

  return (
    <div className="appointment"
        
    >
      <div className='header'>
      <header>Book your Appointment</header>
      </div>
    
    <Form.Select required className="for" onChange={handledoctor} aria-label="Default select example" defaultValue="">
    <option value="" disabled hidden>Select for Specialization</option>
      {
      spec.map((ele,index)=>
        <option key={index}  value={ele.specid}>{ele.specialty}</option>
        )
      }
      </Form.Select>


      <Dropdown className="drop">
                <Dropdown.Toggle variant="info" id="dropdown-basic" required>
                  {docholder}
                </Dropdown.Toggle>

                <Dropdown.Menu  className="men">
                  {doc.map((ele, index) => (
                    <Dropdown.Item key={index} name="Doctor" value={ele.doctorid} onClick={() =>
                      
                      docGetter(ele)
                    }>  {"Doctor" +"-"+ ele.name}  </Dropdown.Item>

                  ))}

                </Dropdown.Menu>
      </Dropdown>


              <Form onSubmit={handleSubmit}>
      <Form.Group controlId="formDate">
        <Form.Label className="dat">Date:</Form.Label>
        <Form.Control
          type="date"
          value={date}
          required
          className="f1"
          onChange={handleDateChange}
        />
      </Form.Group>
      <Form.Group controlId="formTime12hr">
        <Form.Label className="tim">Time (12hr format)</Form.Label>
        <Form.Control
          type="text"
          required
          placeholder="HH:mm AM/PM"
          value={time12hr}
          className="f2"
          onChange={handleTimeChange}
        />
      </Form.Group>
      <Button variant="primary" className="btnn" type="submit">
        Submit
      </Button>
      </Form>
      
    
    
    </div>
  )}
                  



