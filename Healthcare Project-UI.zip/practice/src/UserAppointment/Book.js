import React, { useEffect } from 'react'
import { useNavigate } from 'react-router-dom';
import './Book.css';
export default function Book(){
    const nav=useNavigate();
    return(
        
        <div className="Apt">
 
        <div className="Appoint" onClick={()=>nav("/appt")}>
        <p className="par">Booking Detials</p>
        </div>
        
       <div className="Appoint">
          <p className="par" onClick={()=> nav("/res")}>Appointment result</p>
       </div>
       </div>
      
    )
}
