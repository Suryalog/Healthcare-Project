import React from 'react'
import Col from 'react-bootstrap/Col';
import { Row } from 'react-bootstrap';
import { useState,useEffect } from 'react';
import Form from 'react-bootstrap/Form';
import Dropdown from 'react-bootstrap/Dropdown';
import axios from 'axios';
import Button from 'react-bootstrap/Button';
import './DoctorRegister.css';

const DoctorRegister = () => {

    const [Specialization, setSpecializaiton] = useState([]);
    const [docreg, setDocreg] = useState({ specialty: "", doctor: [{ emailId: "", password: "", name: "", mobile_number: "" }] });
    const [spec, setSpec] = useState('specialization');

    function handledocregister(e) {
        const { name, value } = e.target;
        setDocreg((previousState) => {
          const arr = previousState.doctor.map((doc) => {
            return { ...doc, [name]: value };
            
          });
          return { ...previousState, doctor: arr, specialty: spec };
        })
      }
    
    
      function handleDocbutton() {
        console.log(docreg)
        // if (!docreg.specialty) {
        //     alert('Specialty is required.');
        //     return false;
        //   }
        
        //   // Check if all doctor fields are filled
        //   for (const doc of docreg.doctor) {
        //     if (docreg.specialty != null  && doc.emailId != null && doc.password != null && doc.name != null && doc.mobile_number != null ) {
        //         axios.post("http://localhost:8080/spec", docreg).then(res => alert(res.data))
        //         .catch(e => alert(e.response.data.message))
        //     }else{
        //         alert('All fields are required.');
        //       return false;
        //     }
        //   }
         
        if(docreg.specialty != "" && docreg.doctor[0].emailId != "" && docreg.doctor[0].password != "" && docreg.doctor[0].name != ""
            &&  docreg.doctor[0].number != ""){
                axios.post("http://localhost:8080/spec", docreg).then(res => alert(res.data))
                        .catch(e => alert(e.response.data.message))
            }
        else{
            alert("All the field is required");
        }
            
       
      }


      useEffect(() => {
        axios.get("http://localhost:8080/spectype").then(res => setSpecializaiton(res.data))
      }, []
      )

  return (
    <div>
      <div className="docreg">
      <Dropdown>
                <Dropdown.Toggle variant="success" id="dropdown-basic">
                  {spec}
                </Dropdown.Toggle>

                <Dropdown.Menu  >
                  {Specialization.map((ele, index) => (
                    <Dropdown.Item key={index} name="Specialization" onClick={() => setSpec(ele.specialty
                    )}>  {ele.specialty}  </Dropdown.Item>

                  ))}

                </Dropdown.Menu>
              </Dropdown>



              <Form >
                <Form.Group as={Row} className="mb-3" controlId="formHorizontalEmail">
                  <Form.Label column sm={2}>
                    Email
                  </Form.Label>
                  <Col sm={7}>
                    <Form.Control type="email" placeholder="Email"   name="emailId" onChange={handledocregister} />
                  </Col>
                </Form.Group>

                <Form.Group as={Row} className="mb-3" controlId="formHorizontalPassword">
                  <Form.Label column sm={2}>
                    Password
                  </Form.Label>
                  <Col sm={7}>
                    <Form.Control type="password" placeholder="Password" name="password" onChange={handledocregister} />
                  </Col>
                </Form.Group>
                <Form.Group as={Row} className="mb-3" controlId="formHorizontalEmail">
                  <Form.Label column sm={2}>
                    Name
                  </Form.Label>
                  <Col sm={7}>
                    <Form.Control type="text" placeholder="Name" name="name" onChange={handledocregister} />
                  </Col>
                </Form.Group>
                <Form.Group as={Row} className="mb-3" controlId="formPlaintextPassword">
                  <Form.Label column sm="2">
                    Mobile.No
                  </Form.Label>
                  <Col sm="7">
                    <Form.Control type="tel" placeholder="mobilenum" name="mobile_number" onChange={handledocregister} />
                  </Col>
                </Form.Group>
                <Button className='rbutton' onClick={() => handleDocbutton()}>Submit form</Button>
              </Form>

      </div>
    </div>
  )
}

export default DoctorRegister;
