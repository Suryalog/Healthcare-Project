
import {BrowserRouter, BrowserRouter as Router, Route, Routes, Switch ,Link } from 'react-router-dom';
import Landing from './UserLanding/Landing.js';
import Book from './UserAppointment/Book.js';
import Login from "./Login/Login.js";
import Appointment from './UserAppointment/Appointment.js';
import ApptRes from './UserAppointment/ApptRes.js';
import DoctorLanding from './DoctorLanding/DoctorLanding.js';
import PatientDetails from './DoctorLanding/PatientDetails/PatientDetails.js';
import TesterLanding from './Tester/TesterLanding/TesterLanding.js';
import Sugartest from './Tester/Tests/Sugartest.js';
import Bptest from './Tester/Tests/Bptest.js';
import Bloodtest from './Tester/Tests/Bloodtest.js';
import ReportLanding from './Usertestreport/ReportLanding/ReportLanding.js';
import Usersugartest from './Usertestreport/Userreport/Usersugartest.js';
import Userbptest from './Usertestreport/Userreport/Userbptest.js';
import Userblood from './Usertestreport/Userreport/Userblood.js';
import Updprescription from './DoctorLanding/Updateprescription/Updprescription.js';
import Userprescription from './Userprescription/Userprescription.js';
import DoctorRegister from './DoctorRegister/DoctorRegister.js';


function App() {

  
  return (
    <div className="App">
      
    
        <Routes>
        <Route path="/"  element={<Login/>}></Route>
        <Route path="/landing"  element={<Landing />}></Route>
        <Route path="/book"  element={<Book />}></Route>
        <Route path="/appt"  element={<Appointment />}></Route>
        <Route path="/res"  element={< ApptRes/>}></Route>
        <Route path="/doclanding"  element={< DoctorLanding/>}></Route>
        <Route path="/patient"  element={< PatientDetails/>}></Route>
        <Route path="/testl"  element={< TesterLanding/>}></Route>
        <Route path="/sugartest"  element={< Sugartest/>}></Route>
        <Route path="/bptest"  element={< Bptest/>}></Route>
        <Route path="/bloodtest"  element={< Bloodtest/>}></Route>
        <Route path="/report"  element={< ReportLanding/>}></Route>
        <Route path="/usersugar"  element={< Usersugartest/>}></Route>
        <Route path="/userbp"  element={< Userbptest/>}></Route>
        <Route path="/userblood"  element={< Userblood/>}></Route>
        <Route path="/updpres"  element={< Updprescription/>}></Route>
        <Route path="/userpres" element={<Userprescription/>}></Route>
        <Route path="/docreg" element={<DoctorRegister/>}></Route>
      </Routes>
    </div>
  );
}

export default App;
