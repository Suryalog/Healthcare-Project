import React from 'react'
import "./Landing.css";
import { useState } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faUserDoctor, faStethoscope, faFlask, faPrescription, faTablet, faPills, faSyringe, faNavicon, faX } from '@fortawesome/free-solid-svg-icons';
import { useNavigate } from 'react-router-dom';
import { NavLink } from 'react-router-dom';


export default function Landing(){
const [menuIcon,setMenuIcon] = useState(false)

const nav=useNavigate();


  return (

   

    <div className="land">  



<div className='menu-bar'  >
{menuIcon ? (

<div className='menu' onClick={() => setMenuIcon(false)}>
          <FontAwesomeIcon icon={faX} className="icon" id="menu-ic" />
        </div>
      ) : (
        <div className='menu-hide' onClick={() => setMenuIcon(true)}>
          <FontAwesomeIcon icon={faNavicon} className="icon"   id="menu-ic" />
        </div>
      )}




    </div>
      <div className="apt"><FontAwesomeIcon style={{ fontSize: '7em'}} icon={faUserDoctor}  className="icon" onClick={()=>nav("/book")}/>
       <div className="di">Appointment</div>
       </div>
       <div className="apt"><FontAwesomeIcon style={{ fontSize: '7em'}} icon={faFlask}  className="icon" onClick={()=>nav("/report")}/>
       <div className="di">Test Report</div>
       </div>
       <div className="apt"><FontAwesomeIcon style={{ fontSize: '7em'}} icon={faSyringe}  className="icon" onClick={()=>nav("/userpres")}/>
       <div className="di">Prescription</div>
       </div>
    </div>
  )
}
