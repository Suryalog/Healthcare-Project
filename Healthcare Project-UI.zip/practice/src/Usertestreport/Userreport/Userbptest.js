import React from 'react'

import axios from 'axios';
import './Userbptest.css';
import { useEffect,useState } from 'react';
import Table from 'react-bootstrap/Table';


const Userbptest = () => {
    const[ubp,setUbp]=useState([]);
    useEffect(()=>{
        const usid=JSON.parse(sessionStorage.getItem('currentUser')).user_id;
        axios.get(`http://localhost:8080/pressure/${usid}`).then(res=>setUbp(res.data))
        .catch(e=>alert(e.data));
    },[]);


  return (
    <div className="ubptest">
        <h1 className="usugarheading">Laboratory BP Test Report</h1>
<Table striped bordered hover className="testtable">
      <thead>
        <tr>
          <th>id</th>
          <th>testerid</th>
          <th>Age</th>
          <th>Gender</th>
          <th>Date</th>
          <th>SystolicBP</th>
          <th>S_range</th>
          <th>DiastolicBP(mmHg)</th>
          <th>D_range</th>
        </tr>
      </thead>
      <tbody>
        {ubp.map((ele,index)=>(
            <tr key={index}>
                <td>{index+1}</td>
                <td>{ele.testid}</td>
                <td>{ele.age}</td>
                <td>{ele.gender}</td>
                <td>{ele.date}</td>
                <td>{ele.systolicBP}</td>
                <td>{ele.s_range}</td>
                <td>{ele.diastolicBP}</td>
                <td>{ele.d_range}</td>
            </tr>
        ))}
    </tbody>
    </Table>
      
      
    </div>
  )
}

export default Userbptest
