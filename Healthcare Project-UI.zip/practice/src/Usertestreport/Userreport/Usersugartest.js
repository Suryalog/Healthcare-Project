import React, { useState } from 'react';
import Table from 'react-bootstrap/Table';
import axios from 'axios';
import './Usersugartest.css';
import { useEffect } from 'react';


const Usersugartest = () => {
    const[usugar,setUsugar]=useState([]);
    useEffect(()=>{
        const usid=JSON.parse(sessionStorage.getItem('currentUser')).user_id;
        axios.get(`http://localhost:8080/sugar/${usid}`).then(res=>setUsugar(res.data))
        .catch(e=>alert(e.data));
    },[]);
  return (
    <div className="usugartest">
<h1 className="usugarheading">Laboratory Sugar Test Report</h1>
<Table striped bordered hover className="testtable">
      <thead>
        <tr>
          <th>id</th>
          <th>testerid</th>
          <th>Age</th>
          <th>Gender</th>
          <th>Date</th>
          <th>Fasting Test(mmol/L)</th>
          <th>Gulcosetest(mmol/L)</th>
          <th>AIC test</th>
        </tr>
      </thead>
      <tbody>
        {usugar.map((ele,index)=>(
            <tr key={index}>
                <td>{index+1}</td>
                <td>{ele.testid}</td>
                <td>{ele.age}</td>
                <td>{ele.gender}</td>
                <td>{ele.date}</td>
                <td>{ele.fastingtest}</td>
                <td>{ele.gulcosetest}</td>
                <td>{ele.aictest}</td>
            </tr>
        ))}
    </tbody>
    </Table>
      
    </div>
  )
}

export default Usersugartest
