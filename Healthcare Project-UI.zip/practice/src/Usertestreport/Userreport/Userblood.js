import React from 'react'
import axios from 'axios';
import './Userblood.css';
import { useEffect,useState } from 'react';
import Table from 'react-bootstrap/Table';


const Userblood = () => {

    const[ublood,setUblood]=useState([]);
    useEffect(()=>{
        const usid=JSON.parse(sessionStorage.getItem('currentUser')).user_id;
        axios.get(`http://localhost:8080/blood/${usid}`).then(res=>setUblood(res.data))
        .catch(e=>alert(e.data));
    },[]);



  return (
    <div className="ubloodtest">
         <h1 className="usugarheading">Laboratory Blood Test Report</h1>
<Table striped bordered hover className="testtable">
      <thead>
        <tr>
          <th>id</th>
          <th>testerid</th>
          <th>Age</th>
          <th>Gender</th>
          <th>Date</th>
          <th>Hemoglobin(g/dl)</th>
          <th>RBC(10^6/ul)</th>
          <th>WBC(n/mm2)</th>
          <th>platelet(n/mm3)</th>
          <th>calcium(g/dl)</th>
        </tr>
      </thead>
      <tbody>
        {ublood.map((ele,index)=>(
            <tr key={index}>
                <td>{index+1}</td>
                <td>{ele.testid}</td>
                <td>{ele.age}</td>
                <td>{ele.gender}</td>
                <td>{ele.date}</td>
                <td>{ele.hemoglobin}</td>
                <td>{ele.rbc}</td>
                <td>{ele.wbc}</td>
                <td>{ele.platelet}</td>
                <td>{ele.calcium}</td>
            </tr>
        ))}
    </tbody>
      </Table>
    </div>
  )
}

export default Userblood;
