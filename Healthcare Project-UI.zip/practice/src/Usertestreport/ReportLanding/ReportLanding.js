import React from 'react'
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {faUserFriends, faPrescriptionBottleMedical, faDiagnoses, faSquarePollVertical, faBowlFood, faHouseMedicalCircleCheck, faHouseMedicalFlag, faHouseChimneyMedical, faUserDoctor, faAudioDescription, faDiagramSuccessor, faDisease, faTableCells, faTableCellsRowLock, faTableColumns} from '@fortawesome/free-solid-svg-icons';
import './ReportLanding.css';
import { useNavigate } from "react-router-dom";
const ReportLanding = () => {
    const nav=useNavigate();
  return (
    <div>
        <div>
            <h1 className="uhead">View the Test Reports</h1>
        <div className="uland">
       <div className="uapt"><FontAwesomeIcon style={{ fontSize: '9em'}} icon={faSquarePollVertical}  className="ticon" onClick={()=>nav("/usersugar")} />
       <div className="udi">Sugar Test</div>
       </div>
       <div className="uapt"><FontAwesomeIcon style={{ fontSize: '9em'}} icon={faDiagnoses}  className="ticon" onClick={()=>nav("/userbp")} />
       <div className="udi">Blood Pressure Test</div>
       </div>
       <div className="uapt"><FontAwesomeIcon style={{ fontSize: '9em'}} icon={faTableCells}  className="ticon" onClick={()=>nav("/userblood")}/>
       <div className="udi">Blood Test</div>
       </div>
       </div>
     
    </div>
    </div>
  )
}

export default ReportLanding
