import React from "react";
import { useState } from "react";
import axios from "axios";
import { Col,Row } from "react-bootstrap";
import Form from 'react-bootstrap/Form';
import './Updprescription.css';
import Button from 'react-bootstrap/Button';

const Updprescription=()=>{

    const[updpres,setUpdpres]=useState({userid:"",doctorid:"",date:"",tabletname:"",tabletcount:"",morning:"",afternoon:"",night:""});
   
    const handleupdpres=(e)=>{
        const{name,value}=e.target;
        setUpdpres((prev)=>({
            ...prev,[name]:value
        }))
    }
    
    const handlepresbutton = (e) => {
        e.preventDefault();
        console.log(updpres);
       
        axios.post("http://localhost:8080/tabletsend",updpres).then(res=> alert("Prescription updated"));
        setUpdpres({userid:"",doctorid:"",date:"",tabletname:"",tabletcount:"",morning:"",afternoon:"",night:""});
       
        
      };
    
    
    return(
    <div>
   
        <h3 className="presheading">BloodPressure test</h3>
        <Form className="presfor" onSubmit={handlepresbutton}>
            <div className="presdiv">
                  <Form.Group as={Row} className="mb-3" controlId="formHorizontalEmail">
                    <Form.Label column sm={4}>
                      Doctorid
                    </Form.Label>
                    <Col sm={7}>
                      <Form.Control type="number" required placeholder="Enter the Doctorid" name="doctorid" onChange={handleupdpres}/>
                    </Col>
                  </Form.Group>

                  <Form.Group as={Row} className="mb-3" controlId="formHorizontalPassword" >
                    <Form.Label column sm={4}>
                     Enter the Userid
                    </Form.Label>
                    <Col sm={7}>
                      <Form.Control type="number" required placeholder="Enter the userid" name="userid" onChange={handleupdpres}/>
                    </Col>
                  </Form.Group>

                  <Form.Group as={Row} className="mb-3" controlId="formHorizontalPassword">
                    <Form.Label column sm={4}>
                      Date
                    </Form.Label>
                    <Col sm={7}>
                      <Form.Control type="date" required placeholder="Enter the date" name="date" onChange={handleupdpres}/>
                    </Col>
                  </Form.Group>

                  <Form.Group as={Row} className="mb-3" controlId="formHorizontalPassword">
                    <Form.Label column sm={4}>
                      Tablets name
                    </Form.Label>
                    <Col sm={7}>
                      <Form.Control type="text" required placeholder="Enter the tablets name" name="tabletname"  onChange={handleupdpres}/>
                    </Col>
                  </Form.Group>

                  <Form.Group as={Row} className="mb-3" controlId="formHorizontalPassword">
                    <Form.Label column sm={4}>
                      Tablet Count
                        </Form.Label>
                      <Col sm={7}>
                     <Form.Control type="number" required  placeholder="Enter the count of tablet" name="tabletcount" onChange={handleupdpres}/>
                     </Col>
                </Form.Group>

                
              <Form.Group as={Row} className="mb-3" controlId="formHorizontalPassword">
                    
                    <Form.Label column sm={4}>
                    Morning
                      </Form.Label>
                    <Col sm={7}>
                   <Form.Control type="boolean" required placeholder="Enter the morning" name="morning" onChange={handleupdpres}/>
                   </Col>
              </Form.Group>

                    <Form.Group as={Row} className="mb-3" controlId="formHorizontalPassword">
                    
                      <Form.Label column sm={4}>
                      Afternoon
                        </Form.Label>
                      <Col sm={7}>
                     <Form.Control type="boolean" required  placeholder="Enter for afternoon" name="afternoon" onChange={handleupdpres}/>
                     </Col>
                     </Form.Group>


                     <Form.Group as={Row} className="mb-3" controlId="formHorizontalPassword">
                    
                    <Form.Label column sm={4}>
                    Night
                      </Form.Label>
                    <Col sm={7}>
                   <Form.Control type="boolean" required placeholder="Enter for night" name="night" onChange={handleupdpres}/>
                   </Col>
                 </Form.Group>


                     <Col sm={{ span: 10, offset: 2 }}>
                         <button type="submit" className="updpresbutton">Submit</button>
                    </Col>
                </div>
               </Form>     
       
    </div>
    )
}
export default Updprescription;