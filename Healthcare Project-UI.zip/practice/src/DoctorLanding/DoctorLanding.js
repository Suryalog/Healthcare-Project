import React from 'react'
import { useState } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {faUserFriends, faPrescriptionBottleMedical} from '@fortawesome/free-solid-svg-icons';
import { useNavigate } from 'react-router-dom';
import './DoctorLanding.css';


const DoctorLanding = () => {
    const nav=useNavigate();
  return (
    <div className="landd">
       <div className="aptt"><FontAwesomeIcon style={{ fontSize: '8em'}} icon={faUserFriends}  className="iconn" onClick={()=>nav("/patient")}/>
       <div className="dii">Patient Details</div>
       </div>
       <div className="aptt"><FontAwesomeIcon style={{ fontSize: '8em'}} icon={faPrescriptionBottleMedical}  className="iconn" onClick={()=> nav("/updpres")}/>
       <div className="dii">Update Prescription</div>
       </div>
     
    </div>
    
  )
}

export default DoctorLanding
