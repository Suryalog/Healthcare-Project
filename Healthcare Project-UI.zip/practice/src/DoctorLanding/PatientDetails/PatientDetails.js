import React, { useEffect, useState } from 'react';
import Table from 'react-bootstrap/Table';
import './PatientDetails.css';
import Button from 'react-bootstrap/Button';
import axios from 'axios';

const PatientDetails = () => {
  const [apt, setApt] = useState([]);
  const [count, setCount] = useState(1);

  // Fetch appointments on mount
  useEffect(() => {
    const response = JSON.parse(sessionStorage.getItem('currentDoctor'));

      const docid = response.doctor_id;
      console.log(docid);

      axios.get(`http://localhost:8080/appointmentview/${docid}`)
        .then(res => setApt(res.data.map(ele => ({ ...ele, statee: false }))))
        .catch(e => console.log(e));
    
  }, []);

  // Initialize statee property on mount
  // useEffect(() => {
  //   setApt(prev => prev.map(ele => ({ ...ele, statee: false })));
  // }, []); // Removed apt from dependencies to prevent infinite loop

  // Handle accept action
  function handleAccept(e) {
    const aptid = e.aptid;
    setApt(prev => prev.map(ele => (ele.aptid === aptid ? { ...ele, statee: true } : ele)));

    axios.put(`http://localhost:8080/statusupdate/${aptid}`)
      .then(res => res.data)
      .catch(e => alert(e.data));
  }

  // Handle decline action
  function handleDecline(e) {
    const aptid = e.aptid;
    console.log(aptid);
    setApt(prev => prev.map(ele => (ele.aptid === aptid ? { ...ele, statee: true } : ele)));
    axios.put(`http://localhost:8080/statusdecline/${aptid}`)
      .then(res => res.data)
      .catch(e => alert(e.data));
  }

  return (
    <div>
      <h1 className="header">List of Patients Booking their Appointment</h1>
      <Table striped bordered hover size="sm" className="tab mx-auto">
        <thead>
          <tr>
            <th>ID</th>
            <th>Patient Name</th>
            <th>Booked Date</th>
            <th>Booked Time</th>
            <th>Accept</th>
            <th>Decline</th>
          </tr>
        </thead>
        <tbody>
          {apt.map((ele, index) => (
            <tr key={index}>
              <td>{index + 1}</td> {/* Use index + 1 for ID */}
              <td>{ele.username}</td>
              <td>{ele.date}</td>
              <td>{ele.time}</td>
              <td value={ele.aptid} onClick={() => handleAccept(ele)}>
                <Button style={{ visibility: ele.statee ? 'hidden' : 'visible' }} variant="outline-success">Accept</Button>
              </td>
              <td>
                <button id="dec" style={{ visibility: ele.statee ? 'hidden' : 'visible' }} onClick={() => handleDecline(ele)} className='btn btn-outline-danger'>Decline</button>
              </td>
            </tr>
          ))}
        </tbody>
      </Table>
    </div>
  );
};

export default PatientDetails;
