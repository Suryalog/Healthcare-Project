import React, { useEffect } from 'react';
import Badge from 'react-bootstrap/Badge';
import { useState } from 'react';
import Tab from 'react-bootstrap/Tab';
import './Login.css'
import Tabs from 'react-bootstrap/Tabs';
import 'bootstrap/dist/css/bootstrap.min.css';
import Button from 'react-bootstrap/Button';
import Col from 'react-bootstrap/Col';
import Form from 'react-bootstrap/Form';
import Row from 'react-bootstrap/Row';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';


export default function Login() {
  const nav = useNavigate();

  const [userReg, setUserreg] = useState({ emailId: "", password: "", name: "", mobile_number: "" })
  const [login, setLogin] = useState({ emailId: "", password: "" })

  const [key, setKey] = useState('Login');
  const [Loginkey, Setlokey] = useState('User');
  const [regkey, Setregkey] = useState('User');



  function handlelogin(e) {

    const { name, value } = e.target;

    setLogin((previousState) => {
      return { ...previousState, [name]: value };
    });
  }

  
  function handleuserregister(e) {
    const { name, value } = e.target;
    setUserreg((previousState) => {
      return { ...previousState, [name]: value };
    })

    console.log(userReg)

  }

  function handleUserButton() {

    axios.post("http://localhost:8080/userregister", userReg).then(res => alert(res.data))
    .catch(e=>alert("user mailid already exists"))

  }


  function handleulogin() {
    console.log(login);
    axios.post("http://localhost:8080/userlogin", login)
      .then(async () => {
        var response = await axios.post("http://localhost:8080/userobj",login);
       sessionStorage.setItem('currentUser', JSON.stringify(response.data));
     
      })
      .then(res => {
        nav("/landing");
      })
      .catch(e => alert(e.response.data.message))
  }



  function handleDlogin() {
    console.log(login);
    axios.post("http://localhost:8080/doctorlogin", login)
      .then(async()=> {
        var docobj= await axios.post("http://localhost:8080/doctorobj",login);
        sessionStorage.setItem('currentDoctor',JSON.stringify(docobj.data));
      })
      .then(res => nav("/doclanding"))
      .catch(e => alert(e.response.data.message))
  }



  function handleTlogin() {
    console.log(login);
    axios.post("http://localhost:8080/testlogin", login).then(res => nav("/testl"))
      .catch(e => alert(e.response.data.message))
  }


  function handleAlogin() {
    console.log(login);
    axios.post("http://localhost:8080/adminlogin", login).then(res => nav("/docreg"))
      .catch(e => alert(e.response.data.message))
  }







  return (
    
   <div className="mainone">
    <h1 className="mainheading">Welcome to HealthCare Management</h1>
    <div className='Login'>
      <Tabs
        id="controlled-tab-example"
        activeKey={key}
        onSelect={(k) => setKey(k)}
        className="tabs">


        {/* //Login */}
        <Tab eventKey="login" title="Login" className='tab'  >
          <div className='start'>

            <Tabs activeKey={Loginkey}
              onSelect={(r) => Setlokey(r)} className='inner-login-tab' >





              {/* //Login-user */}
              <Tab eventKey="user" title="User" className='inner-login-tabs'><br></br>

                <Form >
                  <Form.Group as={Row} className="mb-3" controlId="formHorizontalEmail">
                    <Form.Label column sm={2}>
                      Email
                    </Form.Label>
                    <Col sm={7}>
                      <Form.Control type="email" placeholder="Email" name="emailId" onChange={handlelogin} />
                    </Col>
                  </Form.Group>

                  <Form.Group as={Row} className="mb-3" controlId="formHorizontalPassword">
                    <Form.Label column sm={2}>
                      Password
                    </Form.Label>
                    <Col sm={7}>
                      <Form.Control type="password" placeholder="Password" name="password" onChange={handlelogin} />
                    </Col>
                  </Form.Group>

                  <Button className='rbutton' onClick={() => handleulogin()}>login</Button>

                </Form>
              </Tab>






              {/* //Login-doctor */}
              <Tab eventKey="doctor" title="Doctor" className='inner-login-tabs' ><br></br>
                <Form >
                  <Form.Group as={Row} className="mb-3" controlId="formHorizontalEmail">
                    <Form.Label column sm={2}>
                      Email
                    </Form.Label>
                    <Col sm={7}>
                      <Form.Control type="email" name="emailId" placeholder="Email" onChange={handlelogin} />
                    </Col>
                  </Form.Group>

                  <Form.Group as={Row} className="mb-3" controlId="formHorizontalPassword">
                    <Form.Label column sm={2}>
                      Password
                    </Form.Label>
                    <Col sm={7}>
                      <Form.Control name="password" type="password" placeholder="Password" onChange={handlelogin} />
                    </Col>
                  </Form.Group>

                  <Button className='rbutton' onClick={() => handleDlogin()}>login</Button>
                </Form>
              </Tab>



              {/* //Login-tester */}
              <Tab eventKey="tester" title="Tester" className='inner-login-tabs' ><br></br>
                <Form >
                  <Form.Group as={Row} className="mb-3" controlId="formHorizontalEmail">
                    <Form.Label column sm={2}>
                      Email
                    </Form.Label>
                    <Col sm={7} className='password_input' >
                      <Form.Control name="emailId" type="email" placeholder="Email" onChange={handlelogin} />
                    </Col>
                  </Form.Group>

                  <Form.Group as={Row} className="mb-3" controlId="formHorizontalPassword">
                    <Form.Label column sm={2}>
                      Password
                    </Form.Label>
                    <Col sm={7} >
                      <Form.Control name="password" type="password" placeholder="Password" onChange={handlelogin} />
                    </Col>
                  </Form.Group>

                  <Button className='rbutton' onClick={() => handleTlogin()}>login</Button>
                </Form>
              </Tab>


                 {/* {Admin-Login} */}
              <Tab eventKey="admin" title="Admin" className='inner-login-tabs' ><br></br>
                <Form >
                  <Form.Group as={Row} className="mb-3" controlId="formHorizontalEmail">
                    <Form.Label column sm={2}>
                      Email
                    </Form.Label>
                    <Col sm={7} className='password_input' >
                      <Form.Control name="emailId" type="email" placeholder="Email" onChange={handlelogin} />
                    </Col>
                  </Form.Group>

                  <Form.Group as={Row} className="mb-3" controlId="formHorizontalPassword">
                    <Form.Label column sm={2}>
                      Password
                    </Form.Label>
                    <Col sm={7} >
                      <Form.Control name="password" type="password" placeholder="Password" onChange={handlelogin} />
                    </Col>
                  </Form.Group>

                  <Button className='rbutton' onClick={() => handleAlogin()}>login</Button>
                </Form>
              </Tab>


            </Tabs><br></br>
          </div>
        </Tab>








        {/* //Register */}
        <Tab eventKey="register" title="Register" className='tab'>

          <Tabs activeKey={regkey} onSelect={(r) => Setregkey(r)} className='inner-register-tab'>




              {/* //Register-user */}
            <Tab eventKey="user" title="User" className='inner-register-tab'>
              <Form >
                <Form.Group as={Row} className="mb-3" controlId="formHorizontalEmail">
                  <Form.Label column sm={2}>
                    Email
                  </Form.Label>
                  <Col sm={7}>
                    <Form.Control type="email" placeholder="Email" name="emailId" onChange={handleuserregister} />
                  </Col>
                </Form.Group>

                <Form.Group as={Row} className="mb-3" controlId="formHorizontalPassword">
                  <Form.Label column sm={2}>
                    Password
                  </Form.Label>
                  <Col sm={7}>
                    <Form.Control type="password" placeholder="Password" name="password" onChange={handleuserregister} />
                  </Col>
                </Form.Group>
                <Form.Group as={Row} className="mb-3" controlId="formHorizontalEmail">
                  <Form.Label column sm={2}>
                    Name
                  </Form.Label>
                  <Col sm={7}>
                    <Form.Control type="text" placeholder="Name" name="name" onChange={handleuserregister} />
                  </Col>
                </Form.Group>
                <Form.Group as={Row} className="mb-3" controlId="formHorizontalEmail">
                  <Form.Label column sm={2}>
                    Mobile.No
                  </Form.Label>
                  <Col sm={7}>
                    <Form.Control type="tel" placeholder="Mobilenumber" name="mobile_number" onChange={handleuserregister} />
                  </Col>
                </Form.Group>
                <Button className='rbutton' onClick={() => handleUserButton()}>Submit form</Button>
              </Form>
            </Tab>


          </Tabs>
        </Tab>
      </Tabs>

    </div>
    </div>
  )
}