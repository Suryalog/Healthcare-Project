import React from 'react';
import { useEffect, useState } from 'react';
import Table from 'react-bootstrap/Table';
import './Userprescription.css';
import axios from 'axios';

const Userprescription = () => {

    const [pres, setPres] = useState([]);
   
    useEffect(() => {
        const response = JSON.parse(sessionStorage.getItem('currentUser'));
    
          const userid = response.user_id;
          console.log(userid);
    
          axios.get(`http://localhost:8080/tabletreturn/${userid}`)
            .then(res => setPres(res.data))
            .catch(e => console.log(e));
        
      }, []);
 
  return(
    <div>
        <div className="userpres">
        <h1 className="header">Prescription Detials</h1>
      <Table striped bordered hover size="sm" className="tab mx-auto">
        <thead>
          <tr>
            <th>ID</th>
            <th>Doctor Id</th>
            <th>Date</th>
            <th>Tablet Name</th>
            <th>Tablet Count</th>
            <th>Morning</th>
            <th>AfterNoon</th>
            <th>Night</th>
          </tr>
        </thead>
        <tbody>
          {pres.map((ele, index) => (
            <tr key={index}>
              <td>{index + 1}</td>
              <td>{ele.doctorid}</td>
              <td>{ele.date}</td>
              <td>{ele.tabletname}</td>
              <td>{ele.tabletcount}</td>
              <td>{(ele.morning) ? 1 : 0}</td>
              <td>{(ele.afternoon) ? 1 : 0}</td>
              <td>{(ele.night) ? 1 : 0}</td>
            </tr>
          ))}
        </tbody>
      </Table>
      
    </div>
    </div>
  )
}

export default Userprescription
